# v1.2.0
## 09/09/2016

1. [](#improved)
    * Update forms for the newest Form plugin markup. Drop totally custom form markup, extend from forms default twig files

# v1.1.0
## 07/14/2016

1. [](#improved)
    * Remove unneeded streams from Theme YAML
    * Delete unused composer.json
    * Add zh-cn / zh-hk / zh-tw language support
1. [](#bugfix)
    * Fix setting the page language in the html tag
    * Fix pagination
    * Fix layout problem on a blog post when the author is not defined

# v1.0.7
## 01/06/2016

1. [](#bugfix)
    * Minor language updates

# v1.0.6
## 12/11/2015

1. [](#bugfix)
    * Fix form template with nonce support

# v1.0.5
## 11/19/2015

1. [](#bugfix)
    * Plugins CSS loading bug

# v1.0.4
## 11/11/2015

1. [](#bugfix)
    * Blog item date fix
    * Next/Prev fix
    * SimpleForm replaced with Forms

# v1.0.3
## 10/07/2015

1. [](#bugfix)
    * Fix display of blog item date

# v1.0.2
## 09/15/2015

1. [](#new)
    * Minor bugfixes

# v1.0.1
## 09/15/2015

1. [](#new)
    * Bugfixes for Simple Form 1.3.0
    * Bugfixes for markdown extra

# v1.0.0
## 09/15/2015

1. [](#new)
    * ChangeLog started...
