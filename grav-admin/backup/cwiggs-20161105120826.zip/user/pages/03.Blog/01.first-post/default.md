---
title: 'First Post'
content:
    items: '@self.children'
    limit: '5'
    order:
        by: date
        dir: desc
    pagination: '1'
    url_taxonomy_filters: '1'
---

# New Site!
So I've setup a new site, I've been wanting to do some updates for a while, mainly because I got a new job and also because I wanted a section for a blog.  I know the old layout had a blog, but it was really just wrapper around medium.com.

This site is now running on [Grav](https://getgrav.org/) which is a pretty cool flat file CMS, or blog, or whatever you want to call it.  The nice this is it's simlar to Pelican, Jerkyl, etc except it has an admin plugin that allows you to use a GUI to edit pages.  The admin plugin is greate for users that wouldn't want to edit the markdown files from the command line.