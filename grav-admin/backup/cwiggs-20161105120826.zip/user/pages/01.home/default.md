---
title: Home
---

# About Me
I'm a systems administrator, novice programmer, and philosophy enthusiast.

I specialize in Linux systems, but I'm procient in Windows 2003-2012 as well as a little bit of OSX. My day to day is baby sitting servers, making sure websites serve correctly, and emails are sending/receiving.  At night you'll find me working on my homelab, various technology that I find interesting, or riding my bicycle around downtown Phoenix.

## Hobbies
* Open Source Software
* Bicycling
* Technology
* Outdoors

## Contact
* Email: cwiggins at cwiggs.com
* GPG fingerprint: 8777 8154 26B3 3D3E 1739 FFDD 9934 39CD 7F46 F139
* Public SSH Key: [pub_key.txt](pub_key.txt)
